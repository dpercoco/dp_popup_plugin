<?php
/**
 * Plugin Name: DP PopUp Plugin 
 * Description: Display PopUp using a shortcode to insert in a page or post
 * Version: 0.1
 * Text Domain: dp_popup_plugin
 * Author: Dahil Percoco
 * Author URI: https://www.merezco.com
 */

//https://www.tbare.com/2018/10/create-a-simple-wordpress-plugin/
//https://speckyboy.com/getting-started-with-wordpress-shortcodes-examples/
//Adding to template: Click to Add 'ShortCode'. Include in text: [popup-plugin buttonText="DownloadToday"]
   

 function dp_popup_plugin($attributes) {

 	$args = shortcode_atts(array(
        	// default values
                'button_text' => 'Download Today',
      		'button_width' => '120px',
      		'apple_store_url'=> '',
		'google_play_url'=> '',
	    	'banner_image'=> ''
    	), $attributes);              

	$Content = "";
	
	// STYLES //

	$Content .= '<style>';
	$Content .= '.form-popup { display: none; position: fixed; top: 100px; left: 500px; border: 3px solid #663300; z-index: 9;}';
	$Content .= '.form-container { height: 230px;  max-width: 300px;  padding: 10px;  background-color: white;}';
	$Content .= '.centerText { text-align: center;}';
	$Content .= '.centerColumn { display: flex; justify-content: center; align-items: center;}';
	$Content .= '</style>';

	// BANNER //

	$Content .= '<div style="text-align: center; ">'; 
	$Content .= '<input type=button width='.$args['button_width'].' value="'.$args['button_text'].'" class="formSubmitBtn centerText"';
	$Content .= 'onClick="openForm();">';
	$Content .= '</div>';
	$Content .= '<div class="form-popup center" id="myForm">';
	$Content .= '<div style="background-color:#663300">';
	$Content .= '<img src="' .$args['banner_image']. '" height="150" width="300" />';
	$Content .= '</div>';

	// FORM //

	$Content .= '<form action="/action_page.php" class="form-container">';
	$Content .= '<table class="centerColumn">';

	// APPLE BUTTON //
	
	$Content .= '<tr>';
	$Content .= '<td class="centerColumn">';
	$Content .= '<a href="' .$args['apple_store_url']. '" target="_blank">';
	$Content .= '<img loading="lazy" class="alignnone wp-image-117" style="padding-bottom: 10px; padding-top: 10px;" src="https://pantreeweb.com/wordpress/wp-content/uploads/2022/06/apple_download-300x88.png" alt="" width="150" height="44" />';
	$Content .= '</a>';
	$Content .= '</td>';
	$Content .= '</tr>';
	
	// GOOGLE PLAY BUTTON //

	$Content .= '<tr>';
	$Content .= '<td class="centerColumn">';
	$Content .= '<a href="' .$args['google_play_url']. '" target="_blank">';
	$Content .= '<img loading="lazy" class="alignnone wp-image-118" src="https://pantreeweb.com/wordpress/wp-content/uploads/2022/06/google-play-badge-1-300x116.png" alt="" width="180" height="50" />';
	$Content .= '</a>';
	$Content .= '</td>';
	$Content .= '</tr>';         
    
	// CLOSE BUTTON //

	$Content .= '<tr>';
	$Content .= '<td class="centerColumn">';
	$Content .= '<button type="button" class="formSubmitBtn" onclick="closeForm()">Close</button>';
	$Content .= '</td>';
	$Content .= '</tr>';

	$Content .= '</table>';
	$Content .= '</form>';
	$Content .= '</div>';

	$Content .= '<script>';
	$Content .= 'function openForm()  {document.getElementById("myForm").style.display = "block";}';
	$Content .= 'function closeForm() {document.getElementById("myForm").style.display = "none";}';
	$Content .= '</script>';
	 
    return $Content;
}

// Creating shortcode with multiple attributes
function owt_basic_shortcode_social_links($attributes)
{
    $args = shortcode_atts(array(
        // default values
        'fb_username' => 'owthub', // facebook username
        'tw_username' => 'owthub' // twitter username

    ), $attributes);

    $facebook = "<a href='https://www.facebook.com/" . $args['fb_username'] . "'>Follow Us On facebook</a>";
    $twitter = "<a href='https://www.twitter.com/" . $args['tw_username'] . "'>Follow Us On Twitter</a>";

    $output = $facebook . '<p>' . $twitter;

    return $output;
}

add_shortcode('social_links', 'owt_basic_shortcode_social_links');

add_shortcode('popup-plugin', 'dp_popup_plugin');